export interface Track {
  id: any,
  SBDV_NAME: any,
  TRK_SYS_NBR: any,
  dist: any,
  car_capacity: any
}
