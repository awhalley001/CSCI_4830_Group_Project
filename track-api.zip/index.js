const express = require('express');
const cors = require('cors');
const app = express();

const bodyParser = require('body-parser');
const fileUpload = require('express-fileupload');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors({origin:  '*'}));
app.use(fileUpload());

app.get('/yard_capacity/list_tracks_api/',  (req, res) => {
   res.json([
       {
           id: 1,
           SBDV_NAME: 'NPT',
           TRK_SYS_NBR: 18679,
           dist: 8567899.99,
           car_capacity: 923459
       },
       {
           id: 2,
           SBDV_NAME: 'NPT',
           TRK_SYS_NBR: 13459,
           dist: 56799.99,
           car_capacity: 99
       },
       {
           id: 3,
           SBDV_NAME: 'NPT',
           TRK_SYS_NBR: 1899,
           dist: 1899.99,
           car_capacity: 93459
       },
       {
           id: 4,
           SBDV_NAME: 'NPT',
           TRK_SYS_NBR: 18359,
           dist: 18978.99,
           car_capacity: 99
       },
       {
           id: 5,
           SBDV_NAME: 'NPT',
           TRK_SYS_NBR: 1458,
           dist: 135499.99,
           car_capacity: 992345
       }
   ]);
});



app.post('/uploadFile', function(req, res) {
    if (!req.files || Object.keys(req.files).length === 0) {
        return res.status(400).send('No files were uploaded.');
    }
    console.log(req.files.file.data.toString());
    res.status(200).send();
    console.log('received file');
    // req.files.forEach(x => console.log(x));
});

app.listen(8000, () => {
    console.log('Server is running on 8000!')
});